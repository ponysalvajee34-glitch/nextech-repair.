NEXTECH REPAIR - Proyecto Android inicial

Incluye:
- App Android con WebView local.
- Registro de reparaciones y clientes.
- Persistencia local en el teléfono mediante localStorage.
- Estados de reparación.
- Comprobante imprimible con diseño de 80 mm (el tamaño final depende del controlador/impresora).

Para compilar el APK:
1. Instala Android Studio en una computadora.
2. Abre la carpeta NextechRepair.
3. Espera la sincronización de Gradle.
4. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. El APK estará en app/build/outputs/apk/debug/app-debug.apk

Este proyecto es un punto de partida; antes de usarlo para datos reales, prueba copias y la impresión con tu impresora.
